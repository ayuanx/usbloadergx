/****************************************************************************
 * Cheat Menu
 * USB Loader GX 2009
 *
 * cheatmenu.h
 ***************************************************************************/

#ifndef _CHEATMENU_H_
#define _CHEATMENU_H_

int CheatMenu(const char * gameID);

#endif
