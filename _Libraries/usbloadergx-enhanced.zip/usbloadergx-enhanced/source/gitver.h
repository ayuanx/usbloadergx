#ifndef GITVER_H
#define GITVER_H

#ifdef __cplusplus
extern "C"
{
#endif

	const char *commitID();

#ifdef __cplusplus
}
#endif

#endif
