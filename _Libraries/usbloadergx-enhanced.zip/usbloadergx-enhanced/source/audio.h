/****************************************************************************
 * libwiigui Template
 * Tantric 2009
 *
 * audio.h
 * Audio support
 ***************************************************************************/

#ifndef _AUDIO_H_
#define _AUDIO_H_

void InitAudio();
void ShutdownAudio();

#endif
