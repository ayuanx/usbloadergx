#ifndef LOADCOVERIMAGE_H_
#define LOADCOVERIMAGE_H_

GuiImageData *LoadCoverImage(struct discHdr *header, bool Prefere3D = true, bool noCover = true);

#endif
