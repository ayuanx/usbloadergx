#ifndef __BCA_H__
#define __BCA_H__

#ifdef __cplusplus
extern "C"
{
#endif

	u32 do_bca_code(const char *BCAFilepath, u8 *gameid);

#ifdef __cplusplus
}
#endif

#endif
