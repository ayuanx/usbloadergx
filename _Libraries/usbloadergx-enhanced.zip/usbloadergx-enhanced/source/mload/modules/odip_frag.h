#ifndef ODIP_FRAG_H_
#define ODIP_FRAG_H_

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char odip_frag[9120];

#define odip_frag_size sizeof(odip_frag)

#ifdef __cplusplus
}
#endif

#endif
