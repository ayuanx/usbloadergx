#define size_ehcmodule_5 27134

extern unsigned char ehcmodule_5[27134];
