#ifndef DIP_PLUGIN249_H_
#define DIP_PLUGIN249_H_

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char dip_plugin_249[5340];

#define dip_plugin_249_size sizeof(dip_plugin_249)

#ifdef __cplusplus
}
#endif

#endif
